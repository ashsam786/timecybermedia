<style>
address
{
line-height: 2em;
margin-top: 2em;
letter-spacing: 0.1em;
}
</style>

<div class="row" style="margin: 39px 6px 0px 7px;">
	<div class="col-md-6 col-sm-11 col-xs-11 noPadng">
	<div id="map" style="
        width: 100%;
    height: 54vh;
    box-shadow: 0px 0px 5px 2px grey;
">
	<!--iframe
	  width="500"
	  height="500"
	  frameborder="0" style="border:0"
	  src="https://www.google.com/maps/embed/v1/search?key=AIzaSyAJhAFW_n1IalZnHuVHKbpPmUdUye0V5mE&q=prime+time+research+media+pvt+ltd">
	</iframe-->
	</div>
	</div>
	<div class="col-md-6 col-sm-12">
	
		<address>
		  <strong>company Name</strong><br>
Company Address<br>
		 company Address<br>
		  company Address<br>
		  <strong>Landmark:</strong> company Address<br>
		  <i class="fa fa-phone fa-fw"></i> Phone No<br>
		  <i class="fa fa-mobile fa-fw"></i>Phone No<br>
		   <i class="fa fa-envelope fa-fw"></i><a style="margin-left: 9px;" href="mailto:info@timemedia.in">mail id</a>
		</address>
	</div>
</div>
<script>
window.onload = function(){
	if($(window).width() <= 500){
		$('#contactMap').html('<iframe width="330" height="400" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/search?key=AIzaSyAJhAFW_n1IalZnHuVHKbpPmUdUye0V5mE&q=prime+time+research+media+pvt+ltd"></iframe>');
	} else {
		$('#contactMap').html('<iframe width="500" height="500" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/search?key=AIzaSyAJhAFW_n1IalZnHuVHKbpPmUdUye0V5mE&q=prime+time+research+media+pvt+ltd"></iframe>');
	}
}
</script>
<script>
	function initMap() {
  var myLatLng = {lat: 28.528974,lng: 77.257756};

  // Create a map object and specify the DOM element for display.
  var map = new google.maps.Map(document.getElementById('map'), {
    center: myLatLng,
    scrollwheel: false,
    zoom: 16
  });

  // Create a marker and set its position.
  var marker = new google.maps.Marker({
    map: map,
    position: myLatLng,
    title: 'Prime Time Research Media Pvt. Ltd.'
  });
}
	</script>
	
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB4QdxalsJoSEa00gy6vni3HshofcVl_fE&callback=initMap"></script>





