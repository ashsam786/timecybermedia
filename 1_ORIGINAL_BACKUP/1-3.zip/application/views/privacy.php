<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>

<div class="row" id="bodyPanel" class="servicesPage lngTxtPge">
	<div class="col-md-12">
		<div class="minheight" id="privacy">
			<div class="row padAndJustfyTxt">
				<div class="heading"><h1 class="text-center">Privacy Policy</h1></div>
			</div>			
			<div class="row padAndJustfyTxt">
			<div class="serviceBody">
				<p><strong>privacy policy page</strong></p>
			</div>
			</div>
		</div>
	</div>		
</div>