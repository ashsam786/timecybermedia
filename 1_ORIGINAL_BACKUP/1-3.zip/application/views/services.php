<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>

<div class="row lngTxtPge" id="bodyPanel">
	<div class="serviceNav col-md-3 col-md-offset-1" role="tabpanel">
		<h1 class="text-center">Our Services</h1>
		this is service page
	</div>		
</div>