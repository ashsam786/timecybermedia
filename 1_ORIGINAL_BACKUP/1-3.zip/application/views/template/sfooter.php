<div class="footer">
			<div class="footer-one">
				<h2><a href="#">Company Name</a></h2>
				<p>&copy; 2016 comap Name. All Rights Reserved | Template by <a href="http://ewebhub.com/">ewebhub</a></p>
			</div>
			<div class="footer-two">
				<h4>Links</h4>
				<ul>
					<li><a href="<?php echo base_url('');?>">Jackets</a></li>
					<li><a href="<?php echo base_url('');?>">Blazers</a></li>
					<li><a href="<?php echo base_url('');?>">Suits</a></li>
					<li><a href="<?php echo base_url('');?>">Trousers</a></li>
					<li><a href="<?php echo base_url('');?>">Jeans</a></li>
				</ul>
				<!--ul>
					<li><a href="#">Denim</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Shirts</a></li>
					<li><a href="#">T-shirts</a></li>
					<li><a href="#">Polo</a></li>
				</ul-->
			</div>
			<div class="footer-two">
				<h4>Sectors</h4>
				<ul>
					<li><a href="<?php echo base_url('');?>">Coats</a></li>
					<li><a href="<?php echo base_url('');?>">Jackets</a></li>
					<li><a href="<?php echo base_url('');?>">Dresses</a></li>
					<li><a href="<?php echo base_url('');?>">Dresses</a></li>
					<li><a href="<?php echo base_url('');?>">Dresses</a></li>
					
				</ul>
				<!--ul>
					<li><a href="#">Leather</a></li>
					<li><a href="#">Trousers</a></li>
					<li><a href="#">Shorts</a></li>
					<li><a href="#">Jeans</a></li>
					<li><a href="#">Denim</a></li>
				</ul-->
			</div>
			<div class="footer-three">
				<h4>Partners</h4>
				<ul>
					<li><a href="#">Girl</a></li>
					<li><a href="#">Boy</a></li>
					<li><a href="#">Baby girl</a></li>
					<li><a href="#">Baby boy</a></li>
					<li><a href="#">Min</a></li>
				</ul>
			</div>
			<!--div class="footer-three">
				<h4>SHOES & BAGS</h4>
				<ul>
					<li><a href="#">Woman</a></li>
					<li><a href="#">Man</a></li>
					<li><a href="#">Girl</a></li>
					<li><a href="#">Boy</a></li>
				</ul>
			</div-->
			<div class="clearfix"></div>
		</div>
	</div>	
</div>
</div>

<script src="<?php echo base_url('assets/js/bootstrap.js');?>"></script>
<script src="<?php echo base_url('assets/js/custom.js');?>"></script>
<script src="<?php echo base_url('assets/js/main.js');?>"></script>
</body>
</html>